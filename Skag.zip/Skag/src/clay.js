var Clay = require('pebble-clay');
var clayConfig = require('./clay.json');
var clay = new Clay(clayConfig); 