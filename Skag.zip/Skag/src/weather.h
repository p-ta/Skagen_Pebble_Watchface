#pragma once
#include <pebble.h>

void weather_init(TextLayer *weather_layer, TextLayer *symbol_layer);
void weather_deinit(void);

void weather_handle_message(DictionaryIterator *iterator);
