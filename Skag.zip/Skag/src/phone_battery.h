#pragma once
#include <pebble.h>

void phone_battery_init(TextLayer *layer);
void phone_battery_deinit(void);
void phone_battery_update(void);
void phone_battery_handle_message(DictionaryIterator *iterator);
void phone_battery_clear(void);
