#include <pebble.h>

static TextLayer *s_weather_layer;
static TextLayer *s_weather_symbol_layer;
static char s_weather_buffer[16];
static char s_symbol_buffer[8];

static const char* weather_symbol_for_condition(const char *condition);

#define PERSIST_KEY_TEMPERATURE 1001
#define PERSIST_KEY_CONDITIONS 1002

void weather_init(TextLayer *weather_layer, TextLayer *symbol_layer) {
  s_weather_layer = weather_layer;
  s_weather_symbol_layer = symbol_layer;
  
  // Gespeicherte Wetterdaten laden, falls vorhanden
  if (persist_exists(PERSIST_KEY_TEMPERATURE) && persist_exists(PERSIST_KEY_CONDITIONS)) {
    int temp = persist_read_int(PERSIST_KEY_TEMPERATURE);
    char conditions[32];
    persist_read_string(PERSIST_KEY_CONDITIONS, conditions, sizeof(conditions));
    
    const char* symbol = weather_symbol_for_condition(conditions);
    snprintf(s_weather_buffer, sizeof(s_weather_buffer), "%d°", temp);
    snprintf(s_symbol_buffer, sizeof(s_symbol_buffer), "%s", symbol);
    text_layer_set_text(s_weather_layer, s_weather_buffer);
    text_layer_set_text(s_weather_symbol_layer, s_symbol_buffer);
    APP_LOG(APP_LOG_LEVEL_INFO, "Gespeicherte Wetterdaten geladen: %s %s", s_symbol_buffer, s_weather_buffer);
  } else {
    text_layer_set_text(s_weather_layer, "..°");
    text_layer_set_text(s_weather_symbol_layer, "");
  }
  
  layer_mark_dirty(text_layer_get_layer(s_weather_layer));
  layer_mark_dirty(text_layer_get_layer(s_weather_symbol_layer));
}

void weather_deinit() {
  // Cleanup if needed
}

void weather_handle_message(DictionaryIterator *iterator) {
  Tuple *temp_tuple = dict_find(iterator, MESSAGE_KEY_TEMPERATURE);
  Tuple *conditions_tuple = dict_find(iterator, MESSAGE_KEY_CONDITIONS);

  APP_LOG(APP_LOG_LEVEL_INFO, "Wetterdaten verarbeitet - temp: %s, conditions: %s", 
          temp_tuple ? "vorhanden" : "fehlt", 
          conditions_tuple ? "vorhanden" : "fehlt");

  if(temp_tuple && conditions_tuple) {
    // Wetterdaten persistent speichern
    persist_write_int(PERSIST_KEY_TEMPERATURE, temp_tuple->value->int32);
    persist_write_string(PERSIST_KEY_CONDITIONS, conditions_tuple->value->cstring);
    
    const char* symbol = weather_symbol_for_condition(conditions_tuple->value->cstring);
    snprintf(s_weather_buffer, sizeof(s_weather_buffer), "%d°", (int)temp_tuple->value->int32);
    snprintf(s_symbol_buffer, sizeof(s_symbol_buffer), "%s", symbol);
    text_layer_set_text(s_weather_layer, s_weather_buffer);
    text_layer_set_text(s_weather_symbol_layer, s_symbol_buffer);
    layer_mark_dirty(text_layer_get_layer(s_weather_layer));
    layer_mark_dirty(text_layer_get_layer(s_weather_symbol_layer));
    APP_LOG(APP_LOG_LEVEL_INFO, "Wetteranzeige gesetzt: %s %s", s_symbol_buffer, s_weather_buffer);
  } else {
    // Keine neuen Daten - verwende gespeicherte Daten, falls vorhanden
    if (persist_exists(PERSIST_KEY_TEMPERATURE) && persist_exists(PERSIST_KEY_CONDITIONS)) {
      int temp = persist_read_int(PERSIST_KEY_TEMPERATURE);
      char conditions[32];
      persist_read_string(PERSIST_KEY_CONDITIONS, conditions, sizeof(conditions));
      
      const char* symbol = weather_symbol_for_condition(conditions);
      snprintf(s_weather_buffer, sizeof(s_weather_buffer), "%d°", temp);
      snprintf(s_symbol_buffer, sizeof(s_symbol_buffer), "%s", symbol);
      text_layer_set_text(s_weather_layer, s_weather_buffer);
      text_layer_set_text(s_weather_symbol_layer, s_symbol_buffer);
      APP_LOG(APP_LOG_LEVEL_INFO, "Verwende gespeicherte Wetterdaten: %s %s", s_symbol_buffer, s_weather_buffer);
    } else {
      // Nur Platzhalter wenn gar keine Daten vorhanden
      snprintf(s_weather_buffer, sizeof(s_weather_buffer), "..°");
      text_layer_set_text(s_weather_layer, s_weather_buffer);
      text_layer_set_text(s_weather_symbol_layer, "");
      APP_LOG(APP_LOG_LEVEL_INFO, "Keine Wetterdaten verfügbar - Platzhalter: %s", s_weather_buffer);
    }
    layer_mark_dirty(text_layer_get_layer(s_weather_layer));
    layer_mark_dirty(text_layer_get_layer(s_weather_symbol_layer));
  }
}

static const char* weather_symbol_for_condition(const char *condition) {
  if (!condition) return "@";
  if (strstr(condition, "Clear")) return "@"; // Sonne
  if (strstr(condition, "Cloud")) return "~"; // Wolken
  if (strstr(condition, "Rain") || strstr(condition, "Drizzle") || strstr(condition, "Thunderstorm")) return "//"; // Regen
  if (strstr(condition, "Snow")) return "*"; // Schnee
  if (strstr(condition, "Fog") || strstr(condition, "Mist") || strstr(condition, "Haze")) return "#"; // Nebel
  return "@"; // Standard: Sonne
}


