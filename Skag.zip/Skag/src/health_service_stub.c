#include <pebble.h>
#include "health_service.h"

bool health_service_available(void) {
  return true; // oder false, wenn du Health deaktivieren willst
}

