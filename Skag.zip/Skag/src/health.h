
#pragma once

void health_init(void);
void health_deinit(void);
