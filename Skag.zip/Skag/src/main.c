#include "phone_battery.h" // hinzufügen
#include <pebble.h>
#include "weather.h"
#include "health.h"

// Message Keys (müssen mit JS übereinstimmen)
#define MESSAGE_KEY_TEMPERATURE 0
#define MESSAGE_KEY_CONDITIONS 1
#define MESSAGE_KEY_PHONE_BATTERY 2
#define MESSAGE_KEY_BG_COLOR 3
#define MESSAGE_KEY_TIME_COLOR 4
#define MESSAGE_KEY_WEATHER_COLOR 5
#define MESSAGE_KEY_DATE_COLOR 6
#define MESSAGE_KEY_BATTERY_COLOR 7
#define MESSAGE_KEY_PHONE_BATTERY_COLOR 8
#define MESSAGE_KEY_STEPBAR_COLOR 9
#define MESSAGE_KEY_STEPBAR_VISIBLE 10
#define MESSAGE_KEY_STEPBAR_BG_COLOR 11
#define MESSAGE_KEY_NIGHT_MODE 12
#define MESSAGE_KEY_WEATHER_REQUEST 13
#define MESSAGE_KEY_API_KEY 14
#define MESSAGE_KEY_LOCATION_METHOD 15
#define MESSAGE_KEY_MANUAL_LOCATION 16
#define MESSAGE_KEY_PHONE_BATTERY_ENABLED 17

// Persist-Keys für Farben
#define PERSIST_KEY_BG_COLOR 100
#define PERSIST_KEY_TIME_COLOR 101
#define PERSIST_KEY_WEATHER_COLOR 102
#define PERSIST_KEY_DATE_COLOR 103
#define PERSIST_KEY_BATTERY_COLOR 104
#define PERSIST_KEY_PHONE_BATTERY_COLOR 105
#define PERSIST_KEY_STEPBAR_COLOR 106
#define PERSIST_KEY_STEPBAR_BG_COLOR 107
#define PERSIST_KEY_NIGHT_MODE 108
#define PERSIST_KEY_PHONE_BATTERY_ENABLED 109

static Window *s_main_window;
static TextLayer *s_time_hour_layer;
static TextLayer *s_time_min_layer;
static TextLayer *s_weather_layer;
static TextLayer *s_weather_symbol_layer;
static TextLayer *s_date_layer;
static TextLayer *s_battery_layer;
static TextLayer *s_phone_battery_layer;
static Layer *s_step_bar_layer;
// Entferne die Separator-Variablen
// static Layer *s_separator_layer;
// static GColor s_separator_color;

static GFont s_skagen_font_big;
static GFont s_skagen_font_small;
static GFont s_skagen_font_tiny;
static TextLayer *s_steps_debug_layer;

static time_t s_last_weather_request = 0;

// Forward declaration
static bool is_night_time(void);

// Globale Farbvariablen
static GColor s_bg_color;
static GColor s_time_color;
static GColor s_weather_color;
static GColor s_date_color;
static GColor s_battery_color;
static GColor s_phone_battery_color;
static GColor s_stepbar_color;
static GColor s_stepbar_bg_color;
static bool s_night_mode_enabled = false;
static bool s_phone_battery_enabled = true;
// Entferne die separator_layer_update Funktion
// static GColor s_separator_color;

static void request_weather() {
  DictionaryIterator *out_iter;
  if (app_message_outbox_begin(&out_iter) == APP_MSG_OK) {
    dict_write_uint8(out_iter, MESSAGE_KEY_WEATHER_REQUEST, 1);
    app_message_outbox_send();
    s_last_weather_request = time(NULL);
    APP_LOG(APP_LOG_LEVEL_INFO, "Wetterdaten angefordert mit Key %d.", MESSAGE_KEY_WEATHER_REQUEST);
  }
}

static void send_current_config() {
  DictionaryIterator *out_iter;
  if (app_message_outbox_begin(&out_iter) == APP_MSG_OK) {
    // Aktuelle Farben senden
    dict_write_uint8(out_iter, MESSAGE_KEY_BG_COLOR, s_bg_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_TIME_COLOR, s_time_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_WEATHER_COLOR, s_weather_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_DATE_COLOR, s_date_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_BATTERY_COLOR, s_battery_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_PHONE_BATTERY_COLOR, s_phone_battery_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_STEPBAR_COLOR, s_stepbar_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_STEPBAR_BG_COLOR, s_stepbar_bg_color.argb);
    dict_write_uint8(out_iter, MESSAGE_KEY_NIGHT_MODE, s_night_mode_enabled ? 1 : 0);
    
    app_message_outbox_send();
    APP_LOG(APP_LOG_LEVEL_INFO, "Aktuelle Konfiguration gesendet");
  }
}

static void update_time() {
  time_t now = time(NULL);
  struct tm *t = localtime(&now);

  static char h_buf[3], m_buf[3], d_buf[6];
  strftime(h_buf, sizeof(h_buf), "%H", t);
  strftime(m_buf, sizeof(m_buf), "%M", t);
  strftime(d_buf, sizeof(d_buf), "%d.%m", t);

  text_layer_set_text(s_time_hour_layer, h_buf);
  text_layer_set_text(s_time_min_layer, m_buf);
  text_layer_set_text(s_date_layer, d_buf);
}

static void battery_handler(BatteryChargeState state) {
  static char buf[8];
  snprintf(buf, sizeof(buf), "%d%%", state.charge_percent);
  text_layer_set_text(s_battery_layer, buf);
}

void step_layer_mark_dirty() {
  if (s_step_bar_layer) layer_mark_dirty(s_step_bar_layer);
}

static void step_layer_update(Layer *layer, GContext *ctx) {
#if defined(PBL_HEALTH)
  GRect bounds = layer_get_bounds(layer);
  time_t start = time_start_of_today();
  time_t end = time(NULL);
  HealthServiceAccessibilityMask mask = health_service_metric_accessible(HealthMetricStepCount, start, end);
  if(mask & HealthServiceAccessibilityMaskAvailable) {
    HealthValue steps = health_service_sum(HealthMetricStepCount, start, end);
    int goal = 10000;
    int width = (bounds.size.w * steps) / goal;
    if (width > bounds.size.w) width = bounds.size.w;

    static char debug_buf[32];
    snprintf(debug_buf, sizeof(debug_buf), "Schritte: %ld / %d", (long)steps, goal);
    if (s_steps_debug_layer) text_layer_set_text(s_steps_debug_layer, debug_buf);

    APP_LOG(APP_LOG_LEVEL_INFO, "Schritte: %ld / %d, Balkenbreite: %d", (long)steps, goal, width);

    // Farben für Nachtmodus bestimmen
    GColor stepbar_bg_color = s_stepbar_bg_color;
    GColor stepbar_color = s_stepbar_color;
    
    if (s_night_mode_enabled && is_night_time()) {
      stepbar_bg_color = GColorWhite;
      stepbar_color = GColorRed;
    }

    // Hintergrund Stepbar (gesamter Balken)
    graphics_context_set_fill_color(ctx, stepbar_bg_color);
    graphics_fill_rect(ctx, bounds, 0, GCornerNone);

    // Fortschritt in Stepbar-Farbe übermalen
    if (width > 0) {
      graphics_context_set_fill_color(ctx, stepbar_color);
      graphics_fill_rect(ctx, GRect(0, 0, width, bounds.size.h), 0, GCornerNone);
    }
  } else {
    APP_LOG(APP_LOG_LEVEL_ERROR, "Health data unavailable!");
    if (s_steps_debug_layer) text_layer_set_text(s_steps_debug_layer, "Schritte: ?");
  }
#else
  if (s_steps_debug_layer) text_layer_set_text(s_steps_debug_layer, "Health nicht verfügbar");
#endif
}

// Entferne die separator_layer_update Funktion
// static void separator_layer_update(Layer *layer, GContext *ctx) {
//   GRect bounds = layer_get_bounds(layer);
//   graphics_context_set_stroke_color(ctx, s_separator_color);
//   graphics_context_set_stroke_width(ctx, 2);  // dünne Linie
//   graphics_draw_line(ctx, GPoint(0, bounds.size.h / 2), GPoint(bounds.size.w, bounds.size.h / 2));
// }

static void health_event_handler(HealthEventType event, void *context) {
  step_layer_mark_dirty();
}

static bool is_night_time() {
  time_t now = time(NULL);
  struct tm *t = localtime(&now);
  int hour = t->tm_hour;
  return (hour >= 20 || hour < 7);
}

static void apply_colors() {
  GColor bg_color = s_bg_color;
  GColor time_color = s_time_color;
  GColor weather_color = s_weather_color;
  GColor date_color = s_date_color;
  GColor battery_color = s_battery_color;
  GColor phone_battery_color = s_phone_battery_color;

  // Nachtmodus anwenden, falls aktiviert und Nachtzeit
  if (s_night_mode_enabled && is_night_time()) {
    bg_color = GColorBlack;
    time_color = GColorWhite;
    weather_color = GColorWhite;
    date_color = GColorWhite;
    battery_color = GColorWhite;
    phone_battery_color = GColorWhite;
  }

  window_set_background_color(s_main_window, bg_color);
  text_layer_set_text_color(s_time_hour_layer, time_color);
  text_layer_set_text_color(s_time_min_layer, time_color);
  text_layer_set_text_color(s_weather_layer, weather_color);
  text_layer_set_text_color(s_weather_symbol_layer, weather_color);
  text_layer_set_text_color(s_date_layer, date_color);
  text_layer_set_text_color(s_battery_layer, battery_color);
  text_layer_set_text_color(s_phone_battery_layer, phone_battery_color);

  // Telefon-Batterie-Layer dynamisch verstecken/zeigen
  Layer *root = window_get_root_layer(s_main_window);
  Layer *phone_battery_layer = text_layer_get_layer(s_phone_battery_layer);
  
  // Layer entfernen und neu hinzufügen basierend auf Einstellung
  layer_remove_from_parent(phone_battery_layer);
  if (s_phone_battery_enabled) {
    layer_add_child(root, phone_battery_layer);
  }

  // TextLayer-Inhalte neu setzen, damit sie neu gezeichnet werden
  text_layer_set_text(s_time_hour_layer, text_layer_get_text(s_time_hour_layer));
  text_layer_set_text(s_time_min_layer, text_layer_get_text(s_time_min_layer));
  text_layer_set_text(s_weather_layer, text_layer_get_text(s_weather_layer));
  text_layer_set_text(s_weather_symbol_layer, text_layer_get_text(s_weather_symbol_layer));
  text_layer_set_text(s_date_layer, text_layer_get_text(s_date_layer));
  text_layer_set_text(s_battery_layer, text_layer_get_text(s_battery_layer));
  text_layer_set_text(s_phone_battery_layer, text_layer_get_text(s_phone_battery_layer));

  // Stepbar-Layer immer neu zeichnen (auch für Hintergrundfarbe)
  layer_mark_dirty(s_step_bar_layer);
}

static void inbox_received_handler(DictionaryIterator *iterator, void *context) {
  APP_LOG(APP_LOG_LEVEL_INFO, "AppMessage empfangen!");
  weather_handle_message(iterator);
  phone_battery_handle_message(iterator);

  Tuple *bg = dict_find(iterator, MESSAGE_KEY_BG_COLOR);
  Tuple *tc = dict_find(iterator, MESSAGE_KEY_TIME_COLOR);
  Tuple *wc = dict_find(iterator, MESSAGE_KEY_WEATHER_COLOR);
  Tuple *dc = dict_find(iterator, MESSAGE_KEY_DATE_COLOR);
  Tuple *bc = dict_find(iterator, MESSAGE_KEY_BATTERY_COLOR);
  Tuple *pbc = dict_find(iterator, MESSAGE_KEY_PHONE_BATTERY_COLOR);
  Tuple *sc = dict_find(iterator, MESSAGE_KEY_STEPBAR_COLOR);
  Tuple *sbg = dict_find(iterator, MESSAGE_KEY_STEPBAR_BG_COLOR);
  Tuple *nm = dict_find(iterator, MESSAGE_KEY_NIGHT_MODE);
  Tuple *pbe = dict_find(iterator, MESSAGE_KEY_PHONE_BATTERY_ENABLED);
  // Tuple *sep = dict_find(iterator, MESSAGE_KEY_SEPARATOR_COLOR); // entfernen

  bool color_changed = false;
  if(bg) { s_bg_color.argb = (uint8_t)bg->value->int32; persist_write_int(PERSIST_KEY_BG_COLOR, s_bg_color.argb); color_changed = true; }
  if(tc) { s_time_color.argb = (uint8_t)tc->value->int32; persist_write_int(PERSIST_KEY_TIME_COLOR, s_time_color.argb); color_changed = true; }
  if(wc) { s_weather_color.argb = (uint8_t)wc->value->int32; persist_write_int(PERSIST_KEY_WEATHER_COLOR, s_weather_color.argb); color_changed = true; }
  if(dc) { s_date_color.argb = (uint8_t)dc->value->int32; persist_write_int(PERSIST_KEY_DATE_COLOR, s_date_color.argb); color_changed = true; }
  if(bc) { s_battery_color.argb = (uint8_t)bc->value->int32; persist_write_int(PERSIST_KEY_BATTERY_COLOR, s_battery_color.argb); color_changed = true; }
  if(pbc) { s_phone_battery_color.argb = (uint8_t)pbc->value->int32; persist_write_int(PERSIST_KEY_PHONE_BATTERY_COLOR, s_phone_battery_color.argb); color_changed = true; }
  if(sc) { 
    s_stepbar_color.argb = (uint8_t)sc->value->int32; 
    persist_write_int(PERSIST_KEY_STEPBAR_COLOR, s_stepbar_color.argb); 
    color_changed = true; 
    APP_LOG(APP_LOG_LEVEL_INFO, "Stepbar-Farbe geändert auf: %d", s_stepbar_color.argb);
  }
  if(sbg) { 
    s_stepbar_bg_color.argb = (uint8_t)sbg->value->int32; 
    persist_write_int(PERSIST_KEY_STEPBAR_BG_COLOR, s_stepbar_bg_color.argb); 
    color_changed = true; 
    APP_LOG(APP_LOG_LEVEL_INFO, "Stepbar-Hintergrundfarbe geändert auf: %d", s_stepbar_bg_color.argb);
  }
  if(nm) { 
    s_night_mode_enabled = (bool)nm->value->int32; 
    persist_write_bool(PERSIST_KEY_NIGHT_MODE, s_night_mode_enabled); 
    color_changed = true; 
    APP_LOG(APP_LOG_LEVEL_INFO, "Nachtmodus %s", s_night_mode_enabled ? "aktiviert" : "deaktiviert");
  }
  if(pbe) { 
    bool was_enabled = s_phone_battery_enabled;
    s_phone_battery_enabled = (bool)pbe->value->int32; 
    persist_write_bool(PERSIST_KEY_PHONE_BATTERY_ENABLED, s_phone_battery_enabled); 
    APP_LOG(APP_LOG_LEVEL_INFO, "Telefon-Batterie %s", s_phone_battery_enabled ? "aktiviert" : "deaktiviert");
    
    // Telefon-Batterie-Anzeige löschen, wenn deaktiviert
    if (!s_phone_battery_enabled && was_enabled) {
      phone_battery_clear();
    }
    
    apply_colors(); // Telefon-Batterie-Layer verstecken/zeigen
  }

  if(bg || tc || wc || dc || bc || pbc || sc || sbg || nm) {
    apply_colors();
    if(color_changed) {
      request_weather(); // Wetter nach Farbänderung neu anfordern
      APP_LOG(APP_LOG_LEVEL_INFO, "Farben geändert - Wetter wird angefordert");
    }
  }
}

static void main_window_load(Window *window) {
  // Farben aus persistentem Speicher laden, falls vorhanden
  if (persist_exists(PERSIST_KEY_BG_COLOR)) s_bg_color.argb = persist_read_int(PERSIST_KEY_BG_COLOR);
  else s_bg_color = GColorMagenta;
  if (persist_exists(PERSIST_KEY_TIME_COLOR)) s_time_color.argb = persist_read_int(PERSIST_KEY_TIME_COLOR);
  else s_time_color = GColorCyan;
  if (persist_exists(PERSIST_KEY_WEATHER_COLOR)) s_weather_color.argb = persist_read_int(PERSIST_KEY_WEATHER_COLOR);
  else s_weather_color = GColorYellow;
  if (persist_exists(PERSIST_KEY_DATE_COLOR)) s_date_color.argb = persist_read_int(PERSIST_KEY_DATE_COLOR);
  else s_date_color = GColorYellow;
  if (persist_exists(PERSIST_KEY_BATTERY_COLOR)) s_battery_color.argb = persist_read_int(PERSIST_KEY_BATTERY_COLOR);
  else s_battery_color = GColorYellow;
  if (persist_exists(PERSIST_KEY_PHONE_BATTERY_COLOR)) s_phone_battery_color.argb = persist_read_int(PERSIST_KEY_PHONE_BATTERY_COLOR);
  else s_phone_battery_color = GColorYellow;
  if (persist_exists(PERSIST_KEY_STEPBAR_COLOR)) s_stepbar_color.argb = persist_read_int(PERSIST_KEY_STEPBAR_COLOR);
  else s_stepbar_color = GColorCyan;
  if (persist_exists(PERSIST_KEY_STEPBAR_BG_COLOR)) s_stepbar_bg_color.argb = persist_read_int(PERSIST_KEY_STEPBAR_BG_COLOR);
  else s_stepbar_bg_color = GColorWhite;
  if (persist_exists(PERSIST_KEY_NIGHT_MODE)) s_night_mode_enabled = persist_read_bool(PERSIST_KEY_NIGHT_MODE);
  else s_night_mode_enabled = false;
  if (persist_exists(PERSIST_KEY_PHONE_BATTERY_ENABLED)) s_phone_battery_enabled = persist_read_bool(PERSIST_KEY_PHONE_BATTERY_ENABLED);
  else s_phone_battery_enabled = true;
  
  // Telefon-Batterie-Anzeige löschen, wenn deaktiviert
  if (!s_phone_battery_enabled) {
    // phone_battery_clear() wird nach der Initialisierung aufgerufen
  }

  window_set_background_color(window, s_bg_color);
  Layer *root = window_get_root_layer(window);
  GRect bounds = layer_get_bounds(root);

  // Custom Fonts laden
  s_skagen_font_big = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_SKAGEN_REGULAR_42));
  s_skagen_font_small = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_SKAGEN_REGULAR_18));
  s_skagen_font_tiny = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_SKAGEN_REGULAR_14));

  // Stundenanzeige groß und mittig
  s_time_hour_layer = text_layer_create(GRect(55, 32, 72, 50));
  text_layer_set_font(s_time_hour_layer, s_skagen_font_big);
  text_layer_set_text_alignment(s_time_hour_layer, GTextAlignmentCenter);
  text_layer_set_background_color(s_time_hour_layer, GColorClear);
  text_layer_set_text_color(s_time_hour_layer, s_time_color);
  layer_add_child(root, text_layer_get_layer(s_time_hour_layer));

  // Wetter-Symbol einen Pixel höher
  s_weather_symbol_layer = text_layer_create(GRect(15, 59, 20, 25));
  text_layer_set_font(s_weather_symbol_layer, s_skagen_font_tiny);
  text_layer_set_text_alignment(s_weather_symbol_layer, GTextAlignmentLeft);
  text_layer_set_background_color(s_weather_symbol_layer, GColorClear);
  text_layer_set_text_color(s_weather_symbol_layer, s_weather_color);
  text_layer_set_text(s_weather_symbol_layer, "");
  layer_add_child(root, text_layer_get_layer(s_weather_symbol_layer));

  // Wetter-Temperatur
  s_weather_layer = text_layer_create(GRect(26, 60, 30, 25));
  text_layer_set_font(s_weather_layer, s_skagen_font_tiny);
  text_layer_set_text_alignment(s_weather_layer, GTextAlignmentLeft);
  text_layer_set_background_color(s_weather_layer, GColorClear);
  text_layer_set_text_color(s_weather_layer, s_weather_color);
  text_layer_set_text(s_weather_layer, "..°");
  layer_add_child(root, text_layer_get_layer(s_weather_layer));

  // Handy-Akku noch kleiner, rechts neben der Stundenanzeige
  s_phone_battery_layer = text_layer_create(GRect(125, 60, 40, 25));
  text_layer_set_font(s_phone_battery_layer, s_skagen_font_tiny);
  text_layer_set_text_alignment(s_phone_battery_layer, GTextAlignmentRight);
  text_layer_set_background_color(s_phone_battery_layer, GColorClear);
  text_layer_set_text_color(s_phone_battery_layer, s_phone_battery_color);
  text_layer_set_text(s_phone_battery_layer, "..");
  
  // Telefon-Batterie nur anzeigen, wenn aktiviert
  if (s_phone_battery_enabled) {
    layer_add_child(root, text_layer_get_layer(s_phone_battery_layer));
  }

  // Minutenanzeige groß und mittig
  s_time_min_layer = text_layer_create(GRect(55, 90, 72, 50));
  text_layer_set_font(s_time_min_layer, s_skagen_font_big);
  text_layer_set_text_alignment(s_time_min_layer, GTextAlignmentCenter);
  text_layer_set_background_color(s_time_min_layer, GColorClear);
  text_layer_set_text_color(s_time_min_layer, s_time_color);
  layer_add_child(root, text_layer_get_layer(s_time_min_layer));

  // Schrittbalken-Layer (wieder 4px hoch)
  s_step_bar_layer = layer_create(GRect(0, 85, bounds.size.w, 4));
  layer_set_update_proc(s_step_bar_layer, step_layer_update);
  layer_add_child(root, s_step_bar_layer);

  // Datum noch kleiner, links neben der Minutenanzeige
  s_date_layer = text_layer_create(GRect(15, 98, 60, 25));
  text_layer_set_font(s_date_layer, s_skagen_font_tiny);
  text_layer_set_text_alignment(s_date_layer, GTextAlignmentLeft);
  text_layer_set_background_color(s_date_layer, GColorClear);
  text_layer_set_text_color(s_date_layer, s_date_color);
  layer_add_child(root, text_layer_get_layer(s_date_layer));

  // Pebble-Akku noch kleiner, rechts neben der Minutenanzeige
  s_battery_layer = text_layer_create(GRect(125, 98, 40, 25));
  text_layer_set_font(s_battery_layer, s_skagen_font_tiny);
  text_layer_set_text_alignment(s_battery_layer, GTextAlignmentRight);
  text_layer_set_background_color(s_battery_layer, GColorClear);
  text_layer_set_text_color(s_battery_layer, s_battery_color);
  layer_add_child(root, text_layer_get_layer(s_battery_layer));

  // Initialisiere Wetter, Health und Phone-Battery explizit
  weather_init(s_weather_layer, s_weather_symbol_layer);
  health_init();
  phone_battery_init(s_phone_battery_layer);
  
  // Telefon-Batterie-Anzeige löschen, wenn deaktiviert
  if (!s_phone_battery_enabled) {
    phone_battery_clear();
  }

  // Health-Event-Handler abonnieren
  health_service_events_subscribe(health_event_handler, NULL);

  // Pebble-Akku initialisieren
  battery_handler(battery_state_service_peek());
  battery_state_service_subscribe(battery_handler);

  app_message_register_inbox_received(inbox_received_handler);
  app_message_open(1024, 1024);

  // Separator-Layer entfernen
  // GRect sep_bounds = layer_get_bounds(root);
  // int sep_y = 85;
  // s_separator_layer = layer_create(GRect(0, sep_y, sep_bounds.size.w, 2));
  // layer_set_update_proc(s_separator_layer, separator_layer_update);
  // layer_add_child(root, s_separator_layer);

  // Wetter beim Start anfordern
  request_weather();
}

static void main_window_unload(Window *window) {
  text_layer_destroy(s_time_hour_layer);
  text_layer_destroy(s_time_min_layer);
  text_layer_destroy(s_weather_layer);
  text_layer_destroy(s_weather_symbol_layer);
  text_layer_destroy(s_date_layer);
  text_layer_destroy(s_battery_layer);
  text_layer_destroy(s_phone_battery_layer);
  layer_destroy(s_step_bar_layer);
  // layer_destroy(s_separator_layer); // entfernen
  fonts_unload_custom_font(s_skagen_font_big);
  fonts_unload_custom_font(s_skagen_font_small);
  fonts_unload_custom_font(s_skagen_font_tiny);
  health_service_events_unsubscribe();
  battery_state_service_unsubscribe();
}

static void tick_handler(struct tm *tick_time, TimeUnits units_changed) {
  update_time();
  step_layer_mark_dirty();
  
  // Farben aktualisieren (für Nachtmodus)
  apply_colors();
  
  // Alle 20 Minuten Wetterdaten anfordern
  if (tick_time->tm_min % 20 == 0) {
    time_t now = time(NULL);
    if (now - s_last_weather_request >= 60 * 15) { // etwas Puffer
      request_weather();
    }
  }
}

int main(void) {
  s_main_window = window_create();
  window_set_window_handlers(s_main_window, (WindowHandlers) {
    .load = main_window_load,
    .unload = main_window_unload
  });
  window_stack_push(s_main_window, true);

  update_time();
  weather_init(s_weather_layer, s_weather_symbol_layer);
  health_init();
  tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
  app_event_loop();
  phone_battery_deinit();
  tick_timer_service_unsubscribe();
  weather_deinit();
  health_deinit();
  window_destroy(s_main_window);
}
