// Standard API Key (kann überschrieben werden)
var myAPIKey = "97ae9154b0a0c262cbe31fc072827bfc";
var locationMethod = "gps";
var manualLocation = "";
var phoneBatteryEnabled = true;
var phoneBatteryInterval = null;

// Message Keys (müssen mit C-Code übereinstimmen)
var KEY_TEMPERATURE = 0;
var KEY_CONDITIONS = 1;
var KEY_PHONE_BATTERY = 2;
var KEY_BG_COLOR = 3;
var KEY_TIME_COLOR = 4;
var KEY_WEATHER_COLOR = 5;
var KEY_DATE_COLOR = 6;
var KEY_BATTERY_COLOR = 7;
var KEY_PHONE_BATTERY_COLOR = 8;
var KEY_STEPBAR_COLOR = 9;
var KEY_STEPBAR_VISIBLE = 10;
var KEY_STEPBAR_BG_COLOR = 11;
var KEY_NIGHT_MODE = 12;
var KEY_WEATHER_REQUEST = 13;
var KEY_API_KEY = 14;
var KEY_LOCATION_METHOD = 15;
var KEY_MANUAL_LOCATION = 16;
var KEY_PHONE_BATTERY_ENABLED = 17;

function fetchWeather() {
  console.log("fetchWeather wird aufgerufen");
  console.log("Standort-Methode:", locationMethod);
  console.log("Manueller Ort:", manualLocation);
  
  if (locationMethod === "manual" && manualLocation) {
    // Manueller Ort verwenden
    var url = "https://api.openweathermap.org/data/2.5/weather?q=" + 
      encodeURIComponent(manualLocation) + "&appid=" + myAPIKey;
    
    console.log("Wetter-URL (manuell):", url);
    
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
      console.log("Wetter-Response erhalten:", this.responseText);
      var json = JSON.parse(this.responseText);
      var temperature = Math.round(json.main.temp - 273.15); // Kelvin → Celsius
      var conditions = json.weather[0].main;
      var dictionary = {};
      dictionary[KEY_TEMPERATURE] = temperature;
      dictionary[KEY_CONDITIONS] = conditions;
      console.log("Sende Wetter an Pebble: " + JSON.stringify(dictionary));
      Pebble.sendAppMessage(dictionary,
        function() { console.log("Wetter erfolgreich gesendet!"); },
        function(e) { console.log("Wetter Senden fehlgeschlagen: " + JSON.stringify(e)); }
      );
    };
    xhr.onerror = function() {
      console.log("Wetter-Request fehlgeschlagen");
    };
    xhr.open("GET", url);
    xhr.send();
  } else {
    // GPS verwenden
    navigator.geolocation.getCurrentPosition(function(pos) {
      var url = "https://api.openweathermap.org/data/2.5/weather?lat=" +
        pos.coords.latitude + "&lon=" + pos.coords.longitude + "&appid=" + myAPIKey;

      console.log("Wetter-URL (GPS):", url);

      var xhr = new XMLHttpRequest();
      xhr.onload = function () {
        console.log("Wetter-Response erhalten:", this.responseText);
        var json = JSON.parse(this.responseText);
        var temperature = Math.round(json.main.temp - 273.15); // Kelvin → Celsius
        var conditions = json.weather[0].main;
        var dictionary = {};
        dictionary[KEY_TEMPERATURE] = temperature;
        dictionary[KEY_CONDITIONS] = conditions;
        console.log("Sende Wetter an Pebble: " + JSON.stringify(dictionary));
        Pebble.sendAppMessage(dictionary,
          function() { console.log("Wetter erfolgreich gesendet!"); },
          function(e) { console.log("Wetter Senden fehlgeschlagen: " + JSON.stringify(e)); }
        );
      };
      xhr.onerror = function() {
        console.log("Wetter-Request fehlgeschlagen");
      };
      xhr.open("GET", url);
      xhr.send();
    }, function(error) {
      console.log("Geolocation-Fehler:", error);
    });
  }
}

function sendPhoneBatteryStatus() {
  console.log("sendPhoneBatteryStatus wird aufgerufen");
  
  if (!phoneBatteryEnabled) {
    console.log("Telefon-Batterie ist deaktiviert");
    return;
  }
  
  if (typeof navigator.getBattery === 'function') {
    navigator.getBattery().then(function(battery) {
      var phoneBattery = Math.round(battery.level * 100);
      console.log("Telefonbatterie gesendet:", phoneBattery);
      var data = {};
      data[KEY_PHONE_BATTERY] = phoneBattery;
      sendToPebble(data);
    }, function(error) {
      console.log("Telefonbatterie-Fehler: " + error);
    });
  } else {
    console.log("Telefonbatterie nicht unterstützt.");
  }
}

function sendToPebble(data) {
  console.log("Sende an Pebble: " + JSON.stringify(data));
  Pebble.sendAppMessage(data,
    function() { console.log("Nachricht gesendet: " + JSON.stringify(data)); },
    function(e) { console.log("Senden fehlgeschlagen: " + JSON.stringify(e)); }
  );
}

Pebble.addEventListener("ready", function() {
  console.log("PebbleJS ist bereit.");
  fetchWeather();
  
  // Telefon-Batterie nur senden, wenn aktiviert
  if (phoneBatteryEnabled) {
    sendPhoneBatteryStatus();
    phoneBatteryInterval = setInterval(sendPhoneBatteryStatus, 600000); // alle 10 Minuten
  }
  
  setInterval(fetchWeather, 1200000); // alle 20 Minuten Wetter aktualisieren
});

Pebble.addEventListener("appmessage", function(e) {
  console.log("AppMessage empfangen – aktualisiere Daten...");
  console.log("Payload:", JSON.stringify(e.payload));
  
  // Neue Einstellungen verarbeiten
  if (e.payload[KEY_API_KEY] !== undefined) {
    myAPIKey = e.payload[KEY_API_KEY];
    console.log("API Key aktualisiert:", myAPIKey);
  }
  
  if (e.payload[KEY_LOCATION_METHOD] !== undefined) {
    locationMethod = e.payload[KEY_LOCATION_METHOD];
    console.log("Standort-Methode aktualisiert:", locationMethod);
  }
  
  if (e.payload[KEY_MANUAL_LOCATION] !== undefined) {
    manualLocation = e.payload[KEY_MANUAL_LOCATION];
    console.log("Manueller Ort aktualisiert:", manualLocation);
  }
  
  if (e.payload[KEY_PHONE_BATTERY_ENABLED] !== undefined) {
    var wasEnabled = phoneBatteryEnabled;
    phoneBatteryEnabled = e.payload[KEY_PHONE_BATTERY_ENABLED] === 1;
    console.log("Telefon-Batterie aktiviert:", phoneBatteryEnabled);
    
    // Interval verwalten basierend auf Einstellung
    if (phoneBatteryEnabled && !wasEnabled) {
      // Telefon-Batterie wurde aktiviert
      sendPhoneBatteryStatus();
      phoneBatteryInterval = setInterval(sendPhoneBatteryStatus, 600000);
    } else if (!phoneBatteryEnabled && wasEnabled) {
      // Telefon-Batterie wurde deaktiviert
      if (phoneBatteryInterval) {
        clearInterval(phoneBatteryInterval);
        phoneBatteryInterval = null;
      }
    }
  }
  
  // Prüfe auf Wetteranfrage (Key 13) - sowohl als String als auch als Zahl
  if (e.payload[13] || e.payload["13"] || e.payload[KEY_WEATHER_REQUEST] || e.payload["WEATHER_REQUEST"]) {
    console.log("Wetteranfrage erhalten, hole neue Daten...");
    fetchWeather();
  }
});

// Konfigurationsmenü-Integration
Pebble.addEventListener("showConfiguration", function() {
  // Konfiguration direkt öffnen - die aktuellen Einstellungen werden über URL-Parameter übergeben
  Pebble.openURL("https://p-ta.github.io/skagen-config/config.html");
});

Pebble.addEventListener("webviewclosed", function(e) {
  if (e && e.response) {
    var config = JSON.parse(decodeURIComponent(e.response));
    Pebble.sendAppMessage(config);
  }
});

