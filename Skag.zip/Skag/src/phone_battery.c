#include <pebble.h>

static TextLayer *s_phone_battery_layer;

enum {
  KEY_PHONE_BATTERY = 1,
};

void phone_battery_init(TextLayer *layer) {
  s_phone_battery_layer = layer;
  text_layer_set_text(s_phone_battery_layer, "..%");
  layer_mark_dirty(text_layer_get_layer(s_phone_battery_layer));
}

void phone_battery_handle_message(DictionaryIterator *iterator) {
  Tuple *bat_tuple = dict_find(iterator, MESSAGE_KEY_PHONE_BATTERY);
  
  APP_LOG(APP_LOG_LEVEL_INFO, "Phone-Battery verarbeitet - battery: %s", 
          bat_tuple ? "vorhanden" : "fehlt");
  
  if (bat_tuple) {
    static char buf[8];
    snprintf(buf, sizeof(buf), "%d%%", (int)bat_tuple->value->int32);
    text_layer_set_text(s_phone_battery_layer, buf);
    layer_mark_dirty(text_layer_get_layer(s_phone_battery_layer));
    APP_LOG(APP_LOG_LEVEL_INFO, "Phone-Battery gesetzt: %s", buf);
  }
}

void phone_battery_clear() {
  if (s_phone_battery_layer) {
    text_layer_set_text(s_phone_battery_layer, "");
    layer_mark_dirty(text_layer_get_layer(s_phone_battery_layer));
    APP_LOG(APP_LOG_LEVEL_INFO, "Phone-Battery Anzeige gelöscht");
  }
}

void phone_battery_deinit() {
  // nichts notwendig
}

