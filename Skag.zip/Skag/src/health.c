#include <pebble.h>
#include <health_service.h>

void health_init() {
  if (!health_service_available()) {
    APP_LOG(APP_LOG_LEVEL_ERROR, "Health service not available.");
    return;
  }

  time_t start = time_start_of_today();
  time_t end = time(NULL);

  // KEIN HealthServiceTimeRange verwenden!
  // Stattdessen: direkt Start- und Endzeit übergeben
  HealthValue steps = health_service_sum(HealthMetricStepCount, start, end);

  APP_LOG(APP_LOG_LEVEL_INFO, "Steps today: %ld", (long)steps);
}
void health_deinit(void) {
  // nichts zu tun
}
